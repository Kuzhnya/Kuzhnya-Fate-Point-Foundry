Hooks.on('diceSoNiceReady', (dice3d) => {
  	dice3d.addSystem({id:"kuzhnya",name:"Kuzhnya Fate Point"},false);
	dice3d.addDicePreset({
		type:"dc",
		labels:[
			'modules/kuzhnyafate/textures/tails.webp','modules/kuzhnyafate/textures/heads.webp'
		],
		bumpMaps:[
			'modules/kuzhnyafate/textures/tails_bump.webp','modules/kuzhnyafate/textures/heads_bump.webp'
		],
		system:"kuzhnyafate"
	});
});
